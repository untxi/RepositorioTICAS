import java.awt.*;
import java.applet.*;
import java.awt.image.*;

/*
  <APPLET
      CODE=copiar.class
      WIDTH=600
      HEIGHT=150 >
  </APPLET>
*/

public class copiar extends Applet {
    Image image, image2;

    public void init() 
    {
        image = getImage(getDocumentBase(), "image.jpg");
        int pixels[] = new int[485 * 88];

        PixelGrabber pg = new PixelGrabber(image, 0, 0, 485, 88, pixels, 0, 485);
        try {
            pg.grabPixels();
        }
        catch (InterruptedException e) {}

        for (int loop_index = 0; loop_index < 485 * 88; loop_index++){
            int p = pixels[loop_index];
            int red = 0xff & (p >> 16);
            int green = 0xff & (p >> 8);
            int blue = 0xff & p;
            pixels[loop_index] = (0xff000000 | red << 16 | green << 8 | blue);
        }

        image2 = createImage(new MemoryImageSource(485, 88, pixels, 0 , 485));
    }

    public void paint(Graphics g) 
    {
        g.drawImage(image2, 10, 10, this);
    }
}
