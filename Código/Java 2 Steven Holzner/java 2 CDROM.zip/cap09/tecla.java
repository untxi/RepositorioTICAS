import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

/*
  <APPLET
      CODE=tecla.class
      WIDTH=300
      HEIGHT=200 >
  </APPLET>
*/

public class tecla extends Applet implements KeyListener {

    String text = "";

    public void init()
    {
        addKeyListener(this);
        requestFocus();
    }

    public void paint(Graphics g)
    {
        g.drawString(text, 0, 100);
    }

    public void keyTyped(KeyEvent e) 
    {
        text = text + e.getKeyChar(); 
        repaint(); 
    }

    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
}
