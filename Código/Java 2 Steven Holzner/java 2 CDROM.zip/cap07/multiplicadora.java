import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
  <APPLET
     CODE=multiplicadora.class
     WIDTH=200
     HEIGHT=200 >
   </APPLET>
*/

public class multiplicadora extends Applet implements ActionListener {

    TextField text1, text2, answertext;
    Label multiplylabel;
    Button button1;

    public void init()
    {
        text1 = new TextField(10);
        add(text1);

        multiplylabel = new Label("*");
        add(multiplylabel);

        text2 = new TextField(10);
        add(text2);

        button1 = new Button("=");
        add(button1);
        button1.addActionListener(this); 
                     
        answertext = new TextField(10);
        add(answertext);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == button1){
            //int sum = Integer.parseInt(text1.getText()) + Integer.parseInt(text2.getText());
            //answertext.setText(String.valueOf(sum));
            int product = Integer.parseInt(text1.getText()) * Integer.parseInt(text2.getText());
            answertext.setText(String.valueOf(product));
        }
    }

}
