import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=etiqueta.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class etiqueta extends Applet
{
     Label label1;
     Label label2;
     Label label3;

     public void init()
     {
         label1 = new Label("�Hola desde Java!", Label.LEFT);
         add(label1);
         label2 = new Label("�Hola desde Java!", Label.CENTER);
         add(label2);
         label3 = new Label("�Hola desde Java!", Label.RIGHT);
         add(label3);
     }
}
