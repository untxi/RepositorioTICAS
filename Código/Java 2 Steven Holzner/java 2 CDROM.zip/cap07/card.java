import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*
<APPLET
    CODE=card.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

class cardPanel extends Panel 
{
    Button button;
    Label label;

    cardPanel(card applet, String cardnumber)
    {
        button = new Button("Tarjeta siguiente");
        button.addActionListener(applet);
        add(button);
        label = new Label("Esta es la tarjeta n� " + cardnumber);
        add(label);
    }
}


public class card extends Applet implements ActionListener
{
    int index = 1;
    CardLayout cardlayout;
    cardPanel panel1, panel2, panel3;

    public void init() 
    {
        cardlayout = new CardLayout();
        setLayout(cardlayout);

        panel1 = new cardPanel(this, "uno");
        panel2 = new cardPanel(this, "dos");
        panel3 = new cardPanel(this, "tres");

        add("primero", panel1);
        add("segundo", panel2);
        add("tercero", panel3);

        cardlayout.show(this, "primero");
    }

    public void actionPerformed(ActionEvent event)
    {
        switch(++index){
            case 1:
                cardlayout.show(this, "primero");
                break;
            case 2:
                cardlayout.show(this, "segundo");
                break;
            case 3:
                cardlayout.show(this, "tercero");
                break;
        }
        if(index == 3) index = 0;
        repaint();
    }
}

