import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=clave.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class clave extends Applet implements ActionListener
{
     public TextField text1;
     public TextField text2;

     public void init()
     {
         text1 = new TextField(30);
         add(text1);
         text2 = new TextField(30);
         add(text2);

         text1.setEchoChar('*');
         text1.addActionListener(this);
     }

     public void actionPerformed(ActionEvent e)
     {
         if(e.getSource() == text1){
             text2.setText(text1.getText());
         }
     }
}
