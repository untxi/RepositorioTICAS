import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=boton2.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class boton2 extends Applet implements ActionListener {

    TextField text1;
    Button button1;

    public void init()
    {
        text1 = new TextField(20);
        add(text1);
        button1 = new Button("�Haga clic aqui!");
        add(button1);
        button1.setActionCommand("Bot�n apretado");
        button1.addActionListener(this);
    }

    public void actionPerformed(ActionEvent event)
    {
        String msg = new String ("�Hola desde Java!");
        String command = event.getActionCommand();

        if(command.equals("Bot�n apretado")){
            text1.setText(msg);
        }
    }
}
