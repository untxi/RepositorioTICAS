class synchronize2 
{
    public static void main(String args[]) 
    {
        Shared shared = new Shared();

        CustomThread thread1 = new CustomThread(shared, "uno");
        CustomThread thread2 = new CustomThread(shared, "dos");
        CustomThread thread3 = new CustomThread(shared, "tres");
        CustomThread thread4 = new CustomThread(shared, "cuatro");

        try {
            thread1.join();
            thread2.join();
            thread3.join();
            thread4.join();
        } catch(InterruptedException e) {}
    }
}

class CustomThread extends Thread
{
    Shared shared;

    public CustomThread(Shared shared, String string) 
    {
        super(string);
        this.shared = shared;
        start();
    }

    public void run() {
        synchronized(shared) { 
            shared.doWork(Thread.currentThread().getName());
        }
    }
}

class Shared 
{
    void doWork(String string) 
    {
        System.out.println("Iniciando " + string);

        try {
            Thread.sleep((long) (Math.random() * 500));
        } catch (InterruptedException e) {}

        System.out.println("Finalizando " + string);
    }
}

