class SecondThread implements Runnable 
{
    Thread thread;

    SecondThread() 
    {
        thread = new Thread(this, "segundo");
        System.out.println("Iniciando segundo hilo");
        thread.start(); 
    }

    public void run() 
    {
        try {
            for(int loop_index = 0; loop_index < 10; loop_index++) {
                System.out.println((Thread.currentThread()).getName() 
                    + " hilo aqu�...");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {}

        System.out.println("Final del segundo hilo.");
    }
}

class runnable 
{
    public static void main(String args[]) 
    {
        SecondThread secondthread = new SecondThread(); 

        try {
            for(int loop_index = 0; loop_index < 10; loop_index++) {
                System.out.println((Thread.currentThread()).getName() 
                    + " hilo aqu�...");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {}
    }
}
