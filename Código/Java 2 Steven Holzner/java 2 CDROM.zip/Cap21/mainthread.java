class mainthread 
{
    public static void main(String args[]) 
    {
        Thread thread = Thread.currentThread();

        System.out.println("El hilo principal se llama " + thread.getName());
    }
}
