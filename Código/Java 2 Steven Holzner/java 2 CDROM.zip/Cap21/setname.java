class setname
{
    public static void main(String args[]) 
    {
        Thread thread = Thread.currentThread();

        System.out.println("El nombre original del hilo principal es " + 
            thread.getName());

        thread.setName("El hilo principal");

        System.out.println("El nombre del hilo principal es ahora " + 
            thread.getName());

    }
}
