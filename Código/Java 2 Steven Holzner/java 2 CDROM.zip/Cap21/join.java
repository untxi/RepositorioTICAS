class CustomThread extends Thread 
{
    CustomThread(String name) 
    {
        super(name);
        start(); 
    }

    public void run() 
    {
        try {
            for(int loop_index = 0; loop_index < 4; loop_index++) {
                System.out.println((Thread.currentThread()).getName() 
                    + " hilo aqu�...");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {}

        System.out.println((Thread.currentThread()).getName() + " finaliza.");
    }
}

class join
{
    public static void main(String args[]) 
    {
        CustomThread thread1 = new CustomThread("primer"); 
        CustomThread thread2 = new CustomThread("segundo"); 
        CustomThread thread3 = new CustomThread("tercero"); 
        CustomThread thread4 = new CustomThread("cuarto"); 

        try {
            thread1.join();
            thread2.join();
            thread3.join();
            thread3.join();
        } catch (InterruptedException e) {}
    }
}
 

