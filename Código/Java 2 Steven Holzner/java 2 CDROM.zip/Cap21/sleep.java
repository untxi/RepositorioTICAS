class sleep
{
    public static void main(String args[]) 
    {
        try {
            System.out.println("Hola");
            Thread.sleep(1000);
            System.out.println("desde");
            Thread.sleep(1000);
            System.out.println("Java.");
            Thread.sleep(1000);
        } catch (InterruptedException e) {}
    }
}
