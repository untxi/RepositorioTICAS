import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE = editorpane.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
*/

public class editorpane extends JApplet
{
    JEditorPane jeditorpane = new JEditorPane();

    public editorpane() 
    {
        Container contentPane = getContentPane();

        jeditorpane.setEditable(true);

        jeditorpane.setText("�Hola desde Swing!");

        contentPane.add(new JScrollPane(jeditorpane));
    }
}
