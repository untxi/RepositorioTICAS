import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = password.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class password extends JApplet 
{
    String correctpassword = "�brete s�samo";
    JPasswordField jpasswordfield = new JPasswordField(10);

    public void init() 
    {
        Container contentPane = getContentPane();

        contentPane.setLayout(new FlowLayout());
        contentPane.add(new JLabel("Introduzca su palabra clave: "));
        contentPane.add(jpasswordfield);

        jpasswordfield.setEchoChar('*');

        jpasswordfield.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = new String(jpasswordfield.getPassword());

                if(correctpassword.equals(input))
                    showStatus("Correcta");
                else
                    showStatus("Incorrecta");
            }
        });
    }
}
