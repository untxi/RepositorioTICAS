import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = textpaneimages.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
*/

public class textpaneimages extends JApplet implements ActionListener
{
    JTextPane jtextpane = new JTextPane();
    JButton jbutton = new JButton("P�lsame");

    public void init() 
    {
        Container contentPane = getContentPane();

        jtextpane.setFont(new Font("Times-Roman", Font.BOLD, 18));
        jtextpane.setText("�Hola desde Swing!");

        jbutton.addActionListener(this);
        jtextpane.insertComponent(jbutton);
        jtextpane.insertIcon(new ImageIcon("image.jpg"));

        contentPane.add(jtextpane);
    }

    public void actionPerformed(ActionEvent e)
    {
        showStatus("Hizo clic sobre el bot�n."); 
    }
}

