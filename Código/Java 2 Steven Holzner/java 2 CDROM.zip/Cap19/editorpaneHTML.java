import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

public class editorpaneHTML extends JFrame 
{
    JEditorPane jeditorpane = new JEditorPane();

    public editorpaneHTML() 
    {
        super("Aplicaci�n JEditorPane");

        Container contentPane = getContentPane();
        jeditorpane.setEditable(false);
        String url = "file:" + System.getProperty("user.dir") +
             System.getProperty("file.separator") +
             "page.html";

        try {
            jeditorpane.setPage(url);
        }
        catch(IOException e) {}

        contentPane.add(jeditorpane);
    }

    public static void main(String args[]) 
    {
        final JFrame f = new editorpaneHTML();

        f.setBounds(100, 100, 300, 300);
        f.setVisible(true);
        f.setBackground(Color.white);
        f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}


