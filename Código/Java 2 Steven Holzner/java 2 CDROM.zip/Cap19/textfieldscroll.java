import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

/*
<APPLET
    CODE = textfieldscroll.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
*/

public class textfieldscroll extends JApplet 
{
    private JTextField jtextfield = new JTextField(
        "Aqu� tenemos un bonito texto largo para un campo de texto.", 12);

    public void init() 
    {
        Container contentPane = getContentPane();
        
        contentPane.setLayout(new FlowLayout());
        contentPane.add(new jsliderpanel());
        contentPane.add(jtextfield);
    }

    class jsliderpanel extends JPanel 
    {
        BoundedRangeModel boundedrangemodel = jtextfield.getHorizontalVisibility();
        JSlider jslider = new JSlider(jtextfield.getHorizontalVisibility());

        public jsliderpanel() {
            add(new JLabel("Desplazar el texto:"));

            boundedrangemodel.setExtent(0);

            jslider = new JSlider(boundedrangemodel);
            add(jslider);

            jslider.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent e) {
                    jtextfield.setScrollOffset(jslider.getValue());
                }
            });
        }
    }
}
