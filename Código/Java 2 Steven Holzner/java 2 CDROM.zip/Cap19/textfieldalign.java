import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = textfieldalign.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class textfieldalign extends JApplet 
{
    JTextField jtextfield = new JTextField("�Hola desde Swing!");
    JButton jbutton1, jbutton2, jbutton3; 

    public void init() 
    {
        Container contentPane = getContentPane();

        jtextfield.setColumns(30);

        contentPane.setLayout(new FlowLayout());
        contentPane.add(new buttonpanel());
        contentPane.add(jtextfield);
    }

    class buttonpanel extends JPanel implements ActionListener
    {

        public buttonpanel() 
        {

            jbutton1 = new JButton("Izquierda");            
            jbutton2 = new JButton("Derecha");            
            jbutton3 = new JButton("Centrado");            

            jbutton1.addActionListener(this);
            jbutton2.addActionListener(this);
            jbutton3.addActionListener(this);

            setLayout(new FlowLayout());

            add(new JLabel("Justificaci�n"));
            add(jbutton1);
            add(jbutton2);
            add(jbutton3);

        }

        public void actionPerformed(ActionEvent e) 
        {
            if(e.getSource() == jbutton1) {
                jtextfield.setHorizontalAlignment(JTextField.LEFT);
            } else if(e.getSource() == jbutton2) {
                jtextfield.setHorizontalAlignment(JTextField.RIGHT);
            } else if(e.getSource() == jbutton3) {
                jtextfield.setHorizontalAlignment(JTextField.CENTER);
            }
        }
    }
}
