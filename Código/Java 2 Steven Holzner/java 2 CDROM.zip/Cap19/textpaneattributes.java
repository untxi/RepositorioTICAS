import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;

    /*
<APPLET
    CODE = textpaneattributes.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
    */

public class textpaneattributes extends JApplet
{
    JTextPane jtextpane = new JTextPane();
    String string = new String ( "�Hola desde Swing!\r\n");
    int stringlength = string.length();
    int position = 0;

    public void init() 
    {
        Container contentPane = getContentPane();

        jtextpane.setText ( string );
        StyledDocument styleddocument = jtextpane.getStyledDocument();
        
        Style normal = styleddocument.addStyle ( "normal", null );
        StyleConstants.setFontFamily(normal, "SansSerif");

        Style red = styleddocument.addStyle ( "red", normal );
        StyleConstants.setForeground(red, Color.red);

        Style bold = styleddocument.addStyle ( "bold", normal );
        StyleConstants.setBold(bold, true);

        Style italic = styleddocument.addStyle ( "italic", normal );
        StyleConstants.setItalic(italic, true);

        Style big = styleddocument.addStyle ( "big", normal );
        StyleConstants.setFontSize(big, 24);
        
        styleddocument.setLogicalStyle (position, normal);
        
        position += stringlength;
        jtextpane.setCaretPosition(styleddocument.getLength());
        jtextpane.replaceSelection(string);
        styleddocument = jtextpane.getStyledDocument();
        styleddocument.setLogicalStyle (position, red);

        position += stringlength;
        jtextpane.setCaretPosition(styleddocument.getLength());
        jtextpane.replaceSelection(string);
        styleddocument = jtextpane.getStyledDocument();
        styleddocument.setLogicalStyle (position, bold);

        position += stringlength;
        jtextpane.setCaretPosition(styleddocument.getLength());
        jtextpane.replaceSelection(string);
        styleddocument = jtextpane.getStyledDocument();
        styleddocument.setLogicalStyle (position, italic);
        
        position += stringlength;
        jtextpane.setCaretPosition(styleddocument.getLength());
        jtextpane.replaceSelection(string);
        styleddocument = jtextpane.getStyledDocument();
        styleddocument.setLogicalStyle (position, big);

        contentPane.add(jtextpane);
    }
}

