import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE = textarea.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class textarea extends JApplet 
{
    private JTextArea jtextarea = new JTextArea("�Hola\ndesde\nSwing!", 5, 20);

    public void init() 
    {
        Container contentPane = getContentPane();

        jtextarea.setWrapStyleWord(true);
        jtextarea.setEditable(true);
        jtextarea.setFont(new Font("Times Roman", Font.BOLD, 10));

        contentPane.setLayout(new FlowLayout());
        contentPane.add(new JScrollPane(jtextarea));
    }
}
