import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE = textpane.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
*/

public class textpane extends JApplet
{
    JTextPane jtextpane = new JTextPane();

    public void init() 
    {
        Container contentPane = getContentPane();

        jtextpane.setFont(new Font("Times-Roman", Font.BOLD, 18));
        jtextpane.setText("�Hola desde Swing!");

        contentPane.add(jtextpane);
    }
}

