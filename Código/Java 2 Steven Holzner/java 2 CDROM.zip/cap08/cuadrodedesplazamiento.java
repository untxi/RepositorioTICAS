import java.applet.Applet;
import java.awt.*;

/*
<APPLET
    CODE=cuadrodedesplazamiento.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class cuadrodedesplazamiento extends Applet 
{

    ScrollPane scrollpane1;
    TextPanel t1;

    public void init(){
        scrollpane1 = new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);

        t1 = new TextPanel();
        scrollpane1.add(t1);
        add(scrollpane1);
    }
}

class TextPanel extends Panel
{
    public Dimension getPreferredSize()
    {
        return new Dimension(400, 400);
    }

    public void paint (Graphics g)
    {
        g.drawString ("Esta es una cadena de texto larga que " +
            "parece continuar y continuar y continuar....", 0, 60);
    }
}
