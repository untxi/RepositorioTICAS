import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=lista.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class lista extends Applet implements ActionListener {

    List list1;
    TextField text1;

    public void init(){
        text1 = new TextField(20);
        add(text1);
        list1 = new List(4);
        list1.add("Elemento 1");
        list1.add("Elemento 2");
        list1.add("Elemento 3");
        list1.add("Elemento 4");
        list1.add("Elemento 5");
        list1.add("Elemento 6");
        list1.add("Elemento 7");
        list1.add("Elemento 8");
        list1.add("Elemento 9");
        add(list1); 
        list1.addActionListener(this); 
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == list1){
            text1.setText(((List) e.getSource()).getSelectedItem());
        }
    }
}
