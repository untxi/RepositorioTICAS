import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=reemplazar.class
    WIDTH=200
    HEIGHT=200 >
</APPLET>
*/

public class reemplazar extends Applet implements ActionListener 
{
    TextArea textarea1;
    Button button1;

    public void init()
    {
        textarea1 = new TextArea("Ya es la hora.", 5, 20,
            TextArea.SCROLLBARS_BOTH);
        add(textarea1);
        button1 = new Button("Cambiar el texto seleccionado");
        add(button1);
        button1.addActionListener(this);
    }

    public void actionPerformed (ActionEvent e){
        if(e.getSource() == button1){
            textarea1.replaceRange("�Hola desde Java!", 
                textarea1.getSelectionStart(), 
                textarea1.getSelectionEnd()) ;
        }
    }
}
