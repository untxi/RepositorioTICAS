import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/*
<APPLET
    CODE=seleccionmult.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/

public class seleccionmult extends Applet implements ActionListener {

    List list1;
    TextField text1;
    Button button1;
    String selections[];

    public void init(){
        text1 = new TextField(40);
        add(text1);
        list1 = new List(4, true);
        list1.add("Elemento 1");
        list1.add("Elemento 2");
        list1.add("Elemento 3");
        list1.add("Elemento 4");
        list1.add("Elemento 5");
        list1.add("Elemento 6");
        list1.add("Elemento 7");
        list1.add("Elemento 8");
        list1.add("Elemento 9");
        add(list1); 
        button1 = new Button("Mostrar las selecciones");
        button1.addActionListener(this); 
        add(button1);
    }

    public void actionPerformed(ActionEvent e) 
    {
        String outString = new String("Usted seleccion�:");

        if(e.getSource() == button1){
            selections = list1.getSelectedItems();
            for(int loopIndex = 0; loopIndex < selections.length; loopIndex++){
                outString += " " + selections[loopIndex];
            }
            text1.setText(outString);
        }
    }
}
