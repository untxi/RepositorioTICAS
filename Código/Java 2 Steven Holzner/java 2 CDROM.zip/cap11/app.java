import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class app extends JFrame 
{
    jpanel j;

    public app() 
    {
        super("Aplicaci�n Swing");

        Container contentPane = getContentPane();
        j = new jpanel();
        contentPane.add(j);
    }

    public static void main(String args[]) 
    {
        final JFrame f = new app();

        f.setBounds(100, 100, 300, 300);
        f.setVisible(true);
        f.setBackground(Color.white);
        //f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        //f.addWindowListener(new WindowAdapter() {
        //    public void windowClosed(WindowEvent e) {
        //        System.exit(0);
        //    }
        //});

    }
}

class jpanel extends JPanel 
{
    jpanel()
    {
        setBackground(Color.white);
    }

    public void paintComponent (Graphics g)
    {
        super.paintComponent(g);
        g.drawString("�Hola desde Swing!", 0, 60);
    }
}

