import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/*
<APPLET
    CODE=borde.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/

public class borde extends JApplet 
{
    jpanel j;

    public void init() 
    {
        Container contentPane = getContentPane();

        j = new jpanel();
        j.setBorder(BorderFactory.createRaisedBevelBorder());
        contentPane.add(j);
    }
}

class jpanel extends JPanel 
{
    jpanel()
    {
        setBackground(Color.white);
    }

    public void paintComponent (Graphics g)
    {
        super.paintComponent(g);
        g.drawString("�Hola desde Swing!", 
        getBorder().getBorderInsets(this).left, 60);
    }
}
