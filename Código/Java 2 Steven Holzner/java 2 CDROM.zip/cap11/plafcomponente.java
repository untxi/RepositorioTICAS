import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE=plafcomponente.class
    WIDTH=210
    HEIGHT=200 >
</APPLET>
*/

public class plafcomponente extends JApplet 
{
    public void init() 
    {
        Container contentPane = getContentPane();

        JNewLabel jnewlabel = new JNewLabel(
                "Esta es una etiqueta falsa."); 

        contentPane.setLayout(new FlowLayout());
                                    
        contentPane.add(new JLabel("Esta es una etiqueta real."));
        contentPane.add(jnewlabel);
    }
}

class JNewLabel extends JTextField 
{
    public JNewLabel(String s) 
    {
        super(s);
    }
    public void updateUI() 
    {
        super.updateUI();

        setHighlighter(null);
        setEditable(false);

        LookAndFeel.installBorder(this, "Label.border");

        LookAndFeel.installColorsAndFont(this, "Label.background", 
            "Label.foreground", "Label.font");
    }
}

