import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE=etiquetaimagen.class
    WIDTH=500
    HEIGHT=200 >
</APPLET>
*/

public class etiquetaimagen extends JApplet 
{

  public void init() 
  {
    Container contentPane = getContentPane();

    JLabel jlabel = new JLabel("Etiqueta", new ImageIcon("etiqueta.jpg"), JLabel.CENTER);
    jlabel.setVerticalTextPosition(JLabel.BOTTOM);
    jlabel.setHorizontalTextPosition(JLabel.CENTER);

    contentPane.add(jlabel);
  }
}
