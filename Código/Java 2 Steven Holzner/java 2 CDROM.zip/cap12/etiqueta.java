import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE=etiqueta.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/

public class etiqueta extends JApplet 
{
    public etiqueta() 
    {
        Container contentPane = getContentPane();

        JLabel jlabel = new JLabel("�Hola desde Swing!");

        contentPane.setLayout(new FlowLayout());

        contentPane.add(jlabel);
    }
}
