import java.awt.*;
import javax.swing.*; 
import java.awt.event.*;

/*
<APPLET
    CODE=casilladeactivacionseleccionada.class
    WIDTH=500
    HEIGHT=200 >
</APPLET>
*/

public class casilladeactivacionseleccionada extends JApplet implements ItemListener
{
    JCheckBox checks[];
    JTextField text;

    public void init() 
    {
        Container contentPane = getContentPane();
        contentPane.setLayout(new FlowLayout());

        checks = new JCheckBox[4];

        for(int loop_index = 0; loop_index <= checks.length - 1; loop_index++){

            checks[loop_index] = new JCheckBox("Casilla de activaci�n " + loop_index);
            checks[loop_index].addItemListener(this);
            contentPane.add(checks[loop_index]);
        }

        text = new JTextField(40);

        contentPane.add(text); 
    }

    public void itemStateChanged(ItemEvent e)
    {
        String outString = new String("Actualmente seleccionada: ");

        for(int loop_index = 0; loop_index <= checks.length - 1; loop_index++){
            if(checks[loop_index].isSelected()) {
                outString += " casilla de activaci�n " + loop_index;
            }
        }
        text.setText(outString);
    }
}


