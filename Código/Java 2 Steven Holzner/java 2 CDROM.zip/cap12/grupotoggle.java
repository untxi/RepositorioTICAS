import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE=grupotoggle.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/


public class grupotoggle extends JApplet 
{
    public grupotoggle() 
    {
        Container contentPane = getContentPane();
        ButtonGroup group = new ButtonGroup();

        JToggleButton[] buttons = new JToggleButton[] {
            new JToggleButton(new ImageIcon("toggle.jpg")),
            new JToggleButton(new ImageIcon("toggle.jpg")),
            new JToggleButton(new ImageIcon("toggle.jpg")),
            new JToggleButton(new ImageIcon("toggle.jpg")),
            new JToggleButton(new ImageIcon("toggle.jpg"))
        };

        contentPane.setLayout(new FlowLayout());
        for(int i=0; i < buttons.length; ++i) {
            group.add(buttons[i]);
            contentPane.add(buttons[i]);
        }
    }
}
