import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE=botoniconos.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/


public class botoniconos extends JApplet 
{
    public void init() 
    {
        Container contentPane = getContentPane();
        Icon normal = new ImageIcon("normal.jpg");
        Icon rollover = new ImageIcon("rollover.jpg");
        Icon pressed = new ImageIcon("pulsado.jpg");
        Icon disabled = new ImageIcon("deshabilitado.jpg");
        Icon selected = new ImageIcon("seleccionado.jpg");
        Icon rolloverSelected = new 
            ImageIcon("reseleccionado.jpg");
        Icon disabledSelected = new 
            ImageIcon("deseleccionado.jpg");

        JButton jbutton = new JButton();

        jbutton.setRolloverEnabled(true);

        jbutton.setIcon(normal);
        jbutton.setRolloverIcon(rollover);
        jbutton.setRolloverSelectedIcon(rolloverSelected);
        jbutton.setSelectedIcon(selected);
        jbutton.setPressedIcon(pressed);
        jbutton.setDisabledIcon(disabled);
        jbutton.setDisabledSelectedIcon(disabledSelected);

        contentPane.setLayout(new FlowLayout());
        contentPane.add(jbutton);
    }
}


