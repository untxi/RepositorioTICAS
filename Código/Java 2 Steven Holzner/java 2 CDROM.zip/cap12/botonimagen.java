import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE=botonimagen.class
    WIDTH=600
    HEIGHT=200 >
</APPLET>
*/

public class botonimagen extends JApplet {
    JButton button = new JButton("Bot�n", new ImageIcon("boton.jpg"));
    JTextField text = new JTextField(20);

    public void init() 
    {
        Container contentPane = getContentPane();

        contentPane.setLayout(new FlowLayout());
        contentPane.add(button);
        contentPane.add(text);

        button.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent event) {
                 text.setText("�Hola desde Swing!");
            }
        });
    }
}
