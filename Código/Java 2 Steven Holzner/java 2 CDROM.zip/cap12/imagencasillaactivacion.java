import java.awt.*;
import javax.swing.*; 
import java.awt.event.*;

/*
<APPLET
    CODE=imagencasillaactivacion.class
    WIDTH=340
    HEIGHT=200 >
</APPLET>
*/

public class imagencasillaactivacion extends JApplet implements ItemListener
{
    JCheckBox check1;
    JTextField text;

    public void init() 
    {
        Container contentPane = getContentPane();
        contentPane.setLayout(new FlowLayout());

        check1 = new JCheckBox("Casilla de activaci�n 1", new ImageIcon("normal.jpg"));

        check1.setSelectedIcon(new ImageIcon("seleccionado.jpg"));

        check1.addItemListener(this);

        contentPane.add(check1);

        text = new JTextField(20);

        contentPane.add(text); 
    }

    public void itemStateChanged(ItemEvent e)
    {
        if (e.getItemSelectable() == check1) {
            text.setText("Seleccion� la casilla de activaci�n 1.");
        }
    }
}


