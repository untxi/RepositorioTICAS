import java.io.*;

class bufferedreader 
{
    public static void main(String args[]) throws Exception 
    {
        FileReader filereader = new FileReader("file.txt");
        BufferedReader bufferedreader = new BufferedReader(filereader);
        String instring;

        while((instring = bufferedreader.readLine()) != null) {
            System.out.println(instring);
        }

        filereader.close();
    }
}
