import java.io.*;

public class chararrayreader 
{
    public static void main(String args[]) throws IOException 
    {
        char data[] = {'E','s','t','a',' ','e','s',' ','u', 'n', 'a',
            ' ','c','a','d','e','n','a',' ','d','e',
            ' ','t','e','x','t', 'o', '.'};

        CharArrayReader chararrayreader = new CharArrayReader(data);

        int character;

        while((character = chararrayreader.read()) != -1) {
            System.out.print((char)character);
        }
    }
}
