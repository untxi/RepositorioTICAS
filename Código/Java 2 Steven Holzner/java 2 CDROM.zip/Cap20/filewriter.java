import java.io.*;

class filewriter 
{
    public static void main(String args[]) throws Exception 
    {
        char data[] = {'E','s','t','a',' ','e','s',' ','u', 'n', 'a',
            ' ','c','a','d','e','n','a',' ','d','e',
            ' ','t','e','x','t', 'o', '.'};

        FileWriter filewriter1 = new FileWriter("file1.txt");
        for (int loop_index = 0; loop_index < data.length; loop_index++) {
            filewriter1.write(data[loop_index]);
        }

        FileWriter filewriter2 = new FileWriter("file2.txt");
        filewriter2.write(data);

        FileWriter filewriter3 = new FileWriter("file3.txt");
        filewriter3.write(data, 5, 10);

        filewriter1.close();
        filewriter2.close();
        filewriter3.close();
    }
}
