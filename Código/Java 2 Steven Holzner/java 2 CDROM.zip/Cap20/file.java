import java.io.File;

class file 
{
    public static void main(String args[]) 
    {
        File file1 = new File("file.txt");

        System.out.println("Archivo: " + file1.getName() + (file1.isFile() ? 
            " es un archivo" : " es un filtro"));
        System.out.println("Tama�o: " + file1.length());
        System.out.println("V�a de acceso: " + file1.getPath());
        System.out.println("V�a de acceso absoluta: " + file1.getAbsolutePath());
        System.out.println("Ultima modificaci�n del archivo: " + file1.lastModified());
        System.out.println(file1.exists() ? "El archivo existe" : "El archivo no existe");
        System.out.println(file1.canRead() ? "Se puede leer el archivo" : 
            "No se puede leer el archivo");
        System.out.println(file1.canWrite() ? "Se puede escribir al archivo" : 
            "No se puede leer el archivo");
        System.out.println(file1.isDirectory() ? "El archivo es un directorio" : 
            "El archivo no es un directorio");
    }
}
