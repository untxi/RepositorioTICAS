import java.io.*;

class fileinputstream 
{
    public static void main(String args[]) throws Exception 
    {
        int size;
        FileInputStream fileinputstream = new FileInputStream("fileinputstream.java");

        System.out.println("Bytes disponibles: " + (size = fileinputstream.available()));
        System.out.println("Leyendo 50 bytes....");

        byte bytearray[] = new byte[50];
        if (fileinputstream.read(bytearray) != 50) {
          System.out.println("No se pudieron leer 50 bytes");
        }

        System.out.println(new String(bytearray, 0, 50));

        System.out.println("Ignorando 50 bytes...");

        fileinputstream.skip(50);

        System.out.println("Leyendo 50 bytes....");
        if (fileinputstream.read(bytearray) != 50) {
          System.out.println("No se pudieron leer 50 bytes");
        }
        System.out.println(new String(bytearray, 0, 50));

        fileinputstream.close();
  }
}
