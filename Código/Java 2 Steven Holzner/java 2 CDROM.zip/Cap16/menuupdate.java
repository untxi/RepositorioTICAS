import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = menuupdate.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class menuupdate extends JApplet implements ActionListener
{
    JMenuBar jmenubar = new JMenuBar();

    JMenu jmenu1 = new JMenu("Archivo");
    JMenu jmenu2 = new JMenu("Edici�n");

    JMenuItem jmenuitem1 = new JMenuItem("Nuevo..."),
        jmenuitem2 = new JMenuItem("Abrir..."),
        jmenuitem3 = new JMenuItem("Salir"),
        jmenuitem4 = new JMenuItem("A�adir elemento"),
        jmenuitem5 = new JMenuItem("Eliminar elemento"),
        jmenuitem6 = new JMenuItem("Nuevo elemento");

    public void init() 
    {
        jmenu1.add(jmenuitem1);
        jmenu1.add(jmenuitem2);
        jmenu1.addSeparator();
        jmenu1.add(jmenuitem3);

        jmenuitem1.setActionCommand("Seleccion� Nuevo");
        jmenuitem2.setActionCommand("Seleccion� Abrir");

        jmenuitem1.addActionListener(this);
        jmenuitem2.addActionListener(this);

        jmenu2.add(jmenuitem4);
        jmenu2.add(jmenuitem5);

        jmenuitem4.setActionCommand("Seleccion� Cortar");
        jmenuitem5.setActionCommand("Seleccion� Copiar");

        jmenuitem4.addActionListener(this);
        jmenuitem5.addActionListener(this);

        jmenubar.add(jmenu1);
        jmenubar.add(jmenu2);

        setJMenuBar(jmenubar);
    }

    public void actionPerformed(ActionEvent e) 
    {
        JMenuItem jmenuitem = (JMenuItem)e.getSource();
        if(jmenuitem == jmenuitem4) {
            jmenu2.add(jmenuitem6);
        }
        if(jmenuitem == jmenuitem5) {
            jmenu2.remove(jmenuitem6);
        }
    }
}


