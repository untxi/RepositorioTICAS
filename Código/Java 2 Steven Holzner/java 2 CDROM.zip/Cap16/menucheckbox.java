import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = menucheckbox.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class menucheckbox extends JApplet implements ActionListener
{
    ImageIcon icon = new ImageIcon("item.jpg");

    JCheckBoxMenuItem 
        jcheckboxmenuitem1 = new JCheckBoxMenuItem("Elemento 1", icon),
        jcheckboxmenuitem2 = new JCheckBoxMenuItem("Elemento 2", icon),
        jcheckboxmenuitem3 = new JCheckBoxMenuItem("Elemento 3", icon),
        jcheckboxmenuitem4 = new JCheckBoxMenuItem("Elemento 4", icon);

    public void init() 
    {
        Container contentPane = getContentPane();

        JMenuBar jmenubar = new JMenuBar();
        JMenu jmenu = new JMenu("Elementos de men� de casilla de verificaci�n");

        jcheckboxmenuitem1.addActionListener(this);
        jcheckboxmenuitem2.addActionListener(this);
        jcheckboxmenuitem3.addActionListener(this);
        jcheckboxmenuitem4.addActionListener(this);

        jmenu.add(jcheckboxmenuitem1);
        jmenu.add(jcheckboxmenuitem2);
        jmenu.add(jcheckboxmenuitem3);
        jmenu.add(jcheckboxmenuitem4);

        jmenubar.add(jmenu);
        setJMenuBar(jmenubar);
    }

    public void actionPerformed(ActionEvent e) 
    {
        showStatus("Elemento 1:  " + jcheckboxmenuitem1.getState() + 
            " Elemento 2:  " + jcheckboxmenuitem2.getState() +
            " Elemento 3:  " + jcheckboxmenuitem3.getState() +
            " Elemento 4:  " + jcheckboxmenuitem4.getState());
    }
}
