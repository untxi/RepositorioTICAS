import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = toolbar.class
    WIDTH = 500
    HEIGHT = 280 >
</APPLET>
*/

public class toolbar extends JApplet implements ActionListener, ItemListener
{
    JButton jbutton1 = new JButton("Bot�n 1", new ImageIcon("button.jpg"));
    JButton jbutton2 = new JButton("Bot�n 2", new ImageIcon("button.jpg"));
    JComboBox jcombobox = new JComboBox();

    public void init()
    {
        Container contentPane = getContentPane();

        JToolBar jtoolbar = new JToolBar();

        jbutton1.addActionListener(this);
        jbutton2.addActionListener(this);

        jcombobox.addItem("Elemento 1");
        jcombobox.addItem("Elemento 2");
        jcombobox.addItem("Elemento 3");
        jcombobox.addItem("Elemento 4");
        jcombobox.addItemListener(this);

        jtoolbar.add(jbutton1);
        jtoolbar.addSeparator();
        jtoolbar.add(jbutton2);
        jtoolbar.addSeparator();
        jtoolbar.add(jcombobox);

        //jcombobox.setMaximumSize(jcombobox.getPreferredSize());

        contentPane.add(jtoolbar, BorderLayout.NORTH);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == jbutton1) {
            showStatus("Hizo clic sobre el bot�n 1");
        } else if (e.getSource() == jbutton2) {
            showStatus("Hizo clic sobre el bot�n 2");
        }
    }

    public void itemStateChanged(ItemEvent e) 
    {
        String outString = "";

        if(e.getStateChange() == ItemEvent.SELECTED)
            outString += "Seleccionado: " + (String)e.getItem();
        else
            outString += "Deseleccionado: " + (String)e.getItem();

        showStatus(outString);
    }
}
