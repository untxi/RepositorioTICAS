import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = submenus.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class submenus extends JApplet 
{

    public void init() 
    {
        JMenuBar jmenubar = new JMenuBar();

        JMenu jmenu  = new JMenu("Sub Men�s", true);
        JMenu jsubmenu    = new JMenu("Men� en cascada", true);

        jmenu.add("Elemento 1");
        jmenu.add("Elemento 2");
        jmenu.add("Elemento 3");
        jmenu.add("Elemento 4");

        jsubmenu.add("Sub Elemento 1");
        jsubmenu.add("Sub Elemento 2");
        jsubmenu.add("Sub Elemento 3");
        jsubmenu.add("Sub Elemento 4");

        jmenu.add(jsubmenu);

        jmenubar.add(jmenu);

        setJMenuBar(jmenubar);
    }
}

