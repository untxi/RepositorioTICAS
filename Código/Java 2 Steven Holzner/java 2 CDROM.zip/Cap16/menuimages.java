import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = menuimages.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class menuimages extends JApplet implements ActionListener
{

    ImageIcon icon = new ImageIcon("item.jpg");

    public void init() 
    {
        JMenuBar jmenubar = new JMenuBar();

        JMenu jmenu1 = new JMenu("Archivo");
        JMenuItem jmenuitem1 = new JMenuItem("Nuevo...", icon),
            jmenuitem2 = new JMenuItem("Abrir...", icon),
            jmenuitem3 = new JMenuItem("Salir", icon);

        jmenu1.add(jmenuitem1);
        jmenu1.add(jmenuitem2);
        jmenu1.addSeparator();
        jmenu1.add(jmenuitem3);

        jmenuitem1.setActionCommand("Seleccion� Nuevo");
        jmenuitem2.setActionCommand("Seleccion� Abrir");

        jmenuitem1.addActionListener(this);
        jmenuitem2.addActionListener(this);

        JMenu jmenu2 = new JMenu("Edici�n");
        JMenuItem jmenuitem4 = new JMenuItem("Cortar", icon),
            jmenuitem5 = new JMenuItem("Copiar", icon),
            jmenuitem6 = new JMenuItem("Pegar", icon);

        jmenu2.add(jmenuitem4);
        jmenu2.add(jmenuitem5);
        jmenu2.add(jmenuitem6);

        jmenuitem4.setActionCommand("Seleccion� Cortar");
        jmenuitem5.setActionCommand("Seleccion� Copiar");
        jmenuitem6.setActionCommand("Seleccion� Pegar");

        jmenuitem4.addActionListener(this);
        jmenuitem5.addActionListener(this);
        jmenuitem6.addActionListener(this);

        jmenubar.add(jmenu1);
        jmenubar.add(jmenu2);

        setJMenuBar(jmenubar);
    }

    public void actionPerformed(ActionEvent e) 
    {
        JMenuItem jmenuitem = (JMenuItem)e.getSource();

        showStatus(jmenuitem.getActionCommand());
    }
}


