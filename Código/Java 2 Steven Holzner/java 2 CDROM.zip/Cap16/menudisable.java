import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = menudisable.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class menudisable extends JApplet implements ActionListener
{
    JMenuBar jmenubar = new JMenuBar();

    JMenu jmenu1 = new JMenu("Archivo");
    JMenu jmenu2 = new JMenu("Edici�n");

    JMenuItem jmenuitem1 = new JMenuItem("Nuevo..."),
        jmenuitem2 = new JMenuItem("Abrir..."),
        jmenuitem3 = new JMenuItem("Salir"),
        jmenuitem4 = new JMenuItem("Deshabilitar bot�n inferior"),
        jmenuitem5 = new JMenuItem("Habilitar bot�n inferior"),
        jmenuitem6 = new JMenuItem("Elemento habilitado");

    public void init() 
    {
        jmenu1.add(jmenuitem1);
        jmenu1.add(jmenuitem2);
        jmenu1.addSeparator();
        jmenu1.add(jmenuitem3);

        jmenuitem1.setActionCommand("Seleccion� Nuevo");
        jmenuitem2.setActionCommand("Seleccion� Abrir");

        jmenuitem1.addActionListener(this);
        jmenuitem2.addActionListener(this);

        jmenu2.add(jmenuitem4);
        jmenu2.add(jmenuitem5);
        jmenu2.add(jmenuitem6);

        jmenuitem4.setActionCommand("Seleccion� Cortar");
        jmenuitem5.setActionCommand("Seleccion� Copiar");

        jmenuitem4.addActionListener(this);
        jmenuitem5.addActionListener(this);

        jmenubar.add(jmenu1);
        jmenubar.add(jmenu2);

        setJMenuBar(jmenubar);
    }

    public void actionPerformed(ActionEvent e) 
    {
        JMenuItem jmenuitem = (JMenuItem)e.getSource();
        if(jmenuitem == jmenuitem4) {
            jmenuitem6.setText("Elemento deshabilitado");
            jmenuitem6.setEnabled(false);
        }
        if(jmenuitem == jmenuitem5) {
            jmenuitem6.setText("Elemento habilitado");
            jmenuitem6.setEnabled(true);
        }
    }
}


