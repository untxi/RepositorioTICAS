import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = menucontrols.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class menucontrols extends JApplet implements ActionListener
{
    public void init() 
    {
        JMenuBar jmenubar = new JMenuBar();

        JMenu jmenu1 = new JMenu("Archivo");
        JMenuItem jmenuitem1 = new JMenuItem("Nuevo..."),
            jmenuitem2 = new JMenuItem("Abrir..."),
            jmenuitem3 = new JMenuItem("Salir");
        JButton jbutton = new JButton("�P�lsame!"); 
        jbutton.setActionCommand("Ha hecho clic sobre el bot�n");
        jbutton.addActionListener(this);

        jmenu1.add(jmenuitem1);
        jmenu1.add(jmenuitem2);
        jmenu1.addSeparator();
        jmenu1.add(jbutton);
        jmenu1.addSeparator();
        jmenu1.add(jmenuitem3);

        JMenu jmenu2 = new JMenu("Edici�n");
        JMenuItem jmenuitem4 = new JMenuItem("Cortar"),
            jmenuitem5 = new JMenuItem("Copiar"),
            jmenuitem6 = new JMenuItem("Pegar");

        jmenu2.add(jmenuitem4);
        jmenu2.add(jmenuitem5);
        jmenu2.add(jmenuitem6);

        jmenubar.add(jmenu1);
        jmenubar.add(jmenu2);

        setJMenuBar(jmenubar);
    }

    public void actionPerformed(ActionEvent e) 
    {
       JButton jbutton = (JButton)e.getSource();
       showStatus(jbutton.getActionCommand());
    }
}


