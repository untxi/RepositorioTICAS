import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = popup.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
*/

public class popup extends JApplet implements MouseListener
{
    JLabel jlabel = new JLabel("�Haz clic con el bot�n derecho!", JLabel.CENTER);
    JPopupMenu jpopupmenu = new JPopupMenu();

    public void init() 
    {
        Container contentPane = getContentPane();

        jpopupmenu.add(new JMenuItem("Cortar", new ImageIcon("item.jpg")));
        jpopupmenu.add(new JMenuItem("Copiar", new ImageIcon("item.jpg")));
        jpopupmenu.add(new JMenuItem("Pegar", new ImageIcon("item.jpg")));

        jlabel.addMouseListener(this);
        contentPane.add(jlabel);
    }
    
    public void mousePressed (MouseEvent e) 
    { 
        if((e.getModifiers() & InputEvent.BUTTON3_MASK) == 
            InputEvent.BUTTON3_MASK)
        jpopupmenu.show(jlabel, e.getX(), e.getY());
    }

    public void mouseClicked(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}
