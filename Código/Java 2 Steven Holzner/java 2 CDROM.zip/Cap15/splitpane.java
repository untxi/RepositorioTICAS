import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE = splitpane.class
    WIDTH = 600
    HEIGHT = 200 >
</APPLET>
*/

public class splitpane extends JApplet implements ActionListener
{
    JButton jbutton1, jbutton2, jbutton3;
    JTextField text1 = new JTextField("Texto 1");
    JTextField text2 = new JTextField("Texto 2");
    JSplitPane jsplitpane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, 
        text1, text2);

    public void init()
    {
        Container contentPane = getContentPane();
        JPanel jpanel = new JPanel();

        jbutton1 = new JButton("Expandible con un clic");
        jbutton1.addActionListener(this);
        jpanel.add(jbutton1);

        jbutton2 = new JButton("Divisible horizontalmente");
        jbutton2.addActionListener(this);
        jpanel.add(jbutton2);

        jbutton3 = new JButton("Incrementar el tama�o del divisor");
        jbutton3.addActionListener(this);
        jpanel.add(jbutton3);

        contentPane.add(jsplitpane, BorderLayout.CENTER);
        contentPane.add(jpanel, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == jbutton1) {
            jsplitpane.setOneTouchExpandable(true);
        }
        if(e.getSource() == jbutton2) {
            jsplitpane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
        }
        if(e.getSource() == jbutton3) {
            jsplitpane.setDividerSize(jsplitpane.getDividerSize() + 10);
        }
    }
}

