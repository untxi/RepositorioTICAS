import java.awt.*;
import javax.swing.*;

/*
<APPLET
    CODE = tabbedpane.class
    WIDTH = 400
    HEIGHT = 200 >
</APPLET>
*/

public class tabbedpane extends JApplet 
{
    public void init()
    {
        Container contentPane = getContentPane();

        JTabbedPane jtabbedpane = new JTabbedPane();

        JPanel jpanel1 = new JPanel();
        JPanel jpanel2 = new JPanel();
        JPanel jpanel3 = new JPanel();

        jpanel1.add(new JLabel("Este es el panel 1"));
        jpanel2.add(new JLabel("Este es el panel 2"));
        jpanel3.add(new JLabel("Este es el panel 3"));

        jtabbedpane.addTab("Leng�eta 1", 
                    new ImageIcon("tab.jpg"),
                    jpanel1, "Esta es la leng�eta 1");

        jtabbedpane.addTab("Leng�eta 2", 
                    new ImageIcon("tab.jpg"),
                    jpanel2, "Esta es la leng�eta 2");

        jtabbedpane.addTab("Leng�eta tres", 
                    new ImageIcon("tab.jpg"),
                    jpanel3, "Esta es la leng�eta 3");

        contentPane.setLayout(new BorderLayout());
        contentPane.add(jtabbedpane);
    }
}
