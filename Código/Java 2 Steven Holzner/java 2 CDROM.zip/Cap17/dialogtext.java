import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

    /*
<APPLET
    CODE = dialogtext.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
    */

public class dialogtext extends JApplet implements ActionListener
{
    JButton jbutton = new JButton("Mostrar di�logo");
    String message = "Introduzca el texto";

    public void init() 
    {
        Container contentPane = getContentPane();

        contentPane.setLayout(new FlowLayout());

        contentPane.add(jbutton);

        jbutton.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e) 
    {
        String result = JOptionPane.showInputDialog(message);

        if(result == null)
            showStatus("Hizo clic sobre Cancelar");
        else
            showStatus("Ha escrito: " + result);
    }
}
