import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

    /*
<APPLET
    CODE = dialogcombo.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
    */

public class dialogcombo extends JApplet implements ActionListener
{
    JButton jbutton = new JButton("Mostrar di�logo");

    public void init() 
    {
        Container contentPane = getContentPane();

        contentPane.setLayout(new FlowLayout());

        contentPane.add(jbutton);

        jbutton.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e) 
    {
        String dialogtitle = "Di�logo";
        String dialogmessage = "�Cu�l le gusta m�s?";
        String[] desserts = {
            "tarta de queso", "helado", "mousse", "pastel"
        };
        
        String dessert = (String)JOptionPane.showInputDialog(
            dialogcombo.this, dialogmessage, dialogtitle,
            JOptionPane.QUESTION_MESSAGE, null, 
            desserts, desserts[0]);
            
        if ( dessert == null )
            showStatus ("Puls� Cancelar");
        else
            showStatus ("Su postre favorito: " + dessert );
    }
}