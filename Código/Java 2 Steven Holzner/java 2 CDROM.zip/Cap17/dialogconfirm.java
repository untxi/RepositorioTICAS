import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

    /*
<APPLET
    CODE = dialogconfirm.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
    */

public class dialogconfirm extends JApplet 
{
    JWindow jwindow = new JWindow();

    public void init()
    {
        final Container contentPane = getContentPane();
        JButton jbutton = new JButton("Mostrar di�logo");

        contentPane.setLayout(new FlowLayout());
        contentPane.add(jbutton);

        jbutton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
               int result = JOptionPane.showConfirmDialog((Component) 
                   null, "Seleccione S� o No", "Seleccione S� o No", 
                   JOptionPane.YES_NO_OPTION);                

               if (result == JOptionPane.YES_OPTION) {
                   showStatus("Hizo clic sobre S�.");
               } else {
                   showStatus("Hizo clic sobre No.");
               }
            }
        });
    }
}
