import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;

    /*
<APPLET
    CODE = treedata.class
    WIDTH = 350
    HEIGHT = 280>
</APPLET>
    */

public class treedata extends JApplet 
{
    Hashtable hashtable = new Hashtable();
    Hashtable subhashtable = new Hashtable();
    Hashtable subsubhashtable = new Hashtable();

    String[] strings = new String[] {"Elemento 1", "Elemento 2", 
        "Elemento 3", "Elemento 4", "Elemento 5"};

    public void init() 
    {
        Container contentPane = getContentPane();

        hashtable.put("Elementos", strings);
        hashtable.put("Subelementos", subhashtable);

        subhashtable.put("Elementos", strings);
        subhashtable.put("Elemento 1", new Integer(1));
        subhashtable.put("Elemento 2", new Integer(2));
        subhashtable.put("Elemento 3", new Integer(3));
        subhashtable.put("Elemento con subelementos", subsubhashtable);

        subsubhashtable.put("M�s subelementos", strings);
        subsubhashtable.put("Elemento 1", new Integer(1));
        subsubhashtable.put("Elemento 2", new Integer(2));
        subsubhashtable.put("Elemento 3", new Integer(3));

        JTree hashTree = new JTree(hashtable);

        JScrollPane hashPane = new JScrollPane(hashTree);

        hashTree.expandPath(new TreePath(hashTree.getModel().getRoot()));    

        contentPane.add(hashPane);
    }
}

