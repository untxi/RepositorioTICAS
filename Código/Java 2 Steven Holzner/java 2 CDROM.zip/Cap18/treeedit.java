import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

    /*
<APPLET
    CODE = treeedit.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
    */

public class treeedit extends JApplet implements CellEditorListener
{
    public void init() 
    {
        JTree tree = new JTree();

        getContentPane().add(tree);

        tree.setEditable(true);

        tree.getCellEditor().addCellEditorListener(this);
    }

    public void editingCanceled(ChangeEvent e) 
    {
        CellEditor editor = (CellEditor)e.getSource();

        showStatus("Cambio no realizado");
    }

    public void editingStopped(ChangeEvent e) 
    {
        CellEditor editor = (CellEditor)e.getSource();

        showStatus("Nuevo texto: " + (String)editor.getCellEditorValue());
    }
}
