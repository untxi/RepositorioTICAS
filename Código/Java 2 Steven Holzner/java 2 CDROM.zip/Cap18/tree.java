import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;

    /*
<APPLET
    CODE = tree.class
    WIDTH = 350
    HEIGHT = 280 >
</APPLET>
    */

public class tree extends JApplet 
{
    public void init()
    {
        JTree jtree = new JTree();

        getContentPane().add(new JScrollPane(jtree));
    }
}
