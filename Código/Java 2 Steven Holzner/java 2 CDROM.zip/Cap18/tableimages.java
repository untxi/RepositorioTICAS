import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

    /*
<APPLET
    CODE = tableimages.class
    WIDTH = 600
    HEIGHT = 280 >
</APPLET>
    */

public class tableimages extends JApplet
{
    String[] columns = {"Emparedado", "Disponible", "Precio", "Fecha", "Imagen"};

    Date date = (new GregorianCalendar(2000, 9, 2)).getTime();

    Object[][] data = {
        {"Hamburguesa", new Boolean(false), new Float(4.99), date, new ImageIcon("table.jpg")},

        {"Barbacoa", new Boolean(true), new Float(5.99), date, new ImageIcon("table.jpg")},

        {"Pavo", new Boolean(false), new Float(4.99), date, new ImageIcon("table.jpg")},

        {"Berros", new Boolean(true), new Float(4.99), date, new ImageIcon("table.jpg")},

        {"Queso", new Boolean(false), new Float(4.99), date, new ImageIcon("table.jpg")},

        {"Ternera", new Boolean(true), new Float(4.99), date, new ImageIcon("table.jpg")}
    };
    
    JTable jtable = new JTable(new newModel(data, columns));

    public void init() 
    {
        getContentPane().add(new JScrollPane(jtable));
    }
}

class newModel extends DefaultTableModel 
{
    public newModel(Object[][] data, Object[] columns) 
    {
        super(data, columns);
    }

    public boolean isCellEditable(int row, int col) 
    {
        return false;
    }

    public Class getColumnClass(int column) 
    {
        Vector v = (Vector) dataVector.elementAt(0);

        return v.elementAt(column).getClass();
    }
}

