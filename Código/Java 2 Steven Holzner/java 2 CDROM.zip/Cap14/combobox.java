import java.awt.*;
import javax.swing.*;
//import java.awt.event.*;

/*
<APPLET
    CODE = combobox.class
    WIDTH = 200
    HEIGHT = 200 >
</APPLET>
*/

public class combobox extends JApplet 
{
    private JComboBox jcombobox = new JComboBox();

    public void init() 
    {
        Container contentPane = getContentPane();

        jcombobox.addItem("Elemento 1");
        jcombobox.addItem("Elemento 2");
        jcombobox.addItem("Elemento 3");
        jcombobox.addItem("Elemento 4");
        jcombobox.addItem("Elemento 5");

        contentPane.setLayout(new FlowLayout());
        contentPane.add(jcombobox);
    }
}
