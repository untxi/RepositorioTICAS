import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/*
<APPLET
    CODE=tooltip.class
    WIDTH=300
    HEIGHT=200 >
</APPLET>
*/

public class tooltip extends JApplet {
    JButton button = new JButton("Haz clic aqu�");
    JTextField text = new JTextField(20);

    public void init() 
    {
        Container contentPane = getContentPane();

        contentPane.setLayout(new FlowLayout());

        button.setToolTipText("Esto es un bot�n.");

        contentPane.add(button);
        contentPane.add(text);

        button.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent event) {
                 text.setText("�Hola desde Swing!");
            }
        });
    }
}
