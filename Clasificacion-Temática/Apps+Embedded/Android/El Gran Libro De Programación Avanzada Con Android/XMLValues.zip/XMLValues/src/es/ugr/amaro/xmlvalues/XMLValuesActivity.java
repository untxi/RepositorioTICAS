package es.ugr.amaro.xmlvalues;

import java.io.InputStream;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class XMLValuesActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TextView tv = (TextView) findViewById(R.id.textView);
        
        InputStream input=getResources().openRawResource(R.raw.rss1);
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        try{
        DocumentBuilder builder=factory.newDocumentBuilder();
        Document doc=builder.parse(input);
        doc.normalize();        
        NodeList nodeList=doc.getElementsByTagName("item");
        int nItems=nodeList.getLength();
        tv.append("\nNúmero de items="+nItems+"\n---");
        for(int i=0;i<nItems;i++){
        	Node node = nodeList.item(i);
        	tv.append("\nNode name="+node.getNodeName());
        	tv.append("\nnode Value="+node.getNodeValue());
        	
        	NodeList nodeList2= node.getChildNodes();
        	int nNodes=nodeList2.getLength();
        	tv.append("\nChildNodes="+nNodes+"\n---");
        	
        	for(int j=0;j<nNodes;j++){
        		Node node2= nodeList2.item(j);
            	tv.append("\n---Node "+j+" name="+node2.getNodeName());
            	tv.append("\n        Value="+node2.getNodeValue());
            	
            	if(node2.getNodeType()==Node.ELEMENT_NODE){
            		String valor=node2.getFirstChild().getNodeValue();
            		tv.append("\n    Este nodo es un elemento. " +
            				"\nValor del nodo=\n"+valor);
            	}
        	}
        }
        } catch(Exception e){
        	tv.append("Parsing error");
        }
    }
}