package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class SerieDeAnimaciones extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv1= (TextView) findViewById(R.id.texto1);
        tv1.setText("Serie de animaciones");
        
        TextView tv= (TextView) findViewById(R.id.texto);    
        tv.setText("ANIMANDOME");
        
        Animation td =
        	AnimationUtils.loadAnimation(this,R.anim.serie);
        td.setFillAfter(true);
        td.setRepeatMode(Animation.RESTART);
        td.setRepeatCount(20);
        tv.startAnimation(td);
        
    }
}