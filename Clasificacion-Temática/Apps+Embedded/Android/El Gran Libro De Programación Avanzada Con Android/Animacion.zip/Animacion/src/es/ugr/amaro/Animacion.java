package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class Animacion extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv= (TextView) findViewById(R.id.texto);    
        
        Animation td =
        	AnimationUtils.loadAnimation(this,R.anim.traslacion_derecha);
        td.setFillAfter(true);
        tv.startAnimation(td);        

        tv.append("\n Texto añadido");
    }
}