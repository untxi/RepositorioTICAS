package es.ugr.amaro.dialogodeprogreso;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class DialogoDeProgresoActivity extends Activity 
                                       implements OnClickListener{
	TextView tv;
	ProgressDialog progressDialog;
	int progreso;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        

        tv=(TextView) findViewById(R.id.textView);
        Button boton= (Button) findViewById(R.id.button1);
        boton.setOnClickListener(this);    
    }

	@Override
	public void onClick(View v) {
		showDialog(0);	
		new MyAsyncTask().execute();
	}
		
    @Override
	protected  Dialog onCreateDialog(int id){

    	progressDialog = new ProgressDialog(this);
    	progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    	progressDialog.setIcon(R.drawable.ic_launcher);
    	progressDialog.setTitle("Progreso...");
    	return progressDialog;
    }

    class MyAsyncTask extends AsyncTask<Void,Void,Void>{
    	@Override 
    	protected Void doInBackground(Void...arg0){
    		for(int i=0;i<100;i++){
    			try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
				}
    			progreso=i+1;
    			publishProgress();
    		}
			return null;    		
    	}
    	
    	@Override 
    	protected void onProgressUpdate(Void...progress){
    		progressDialog.setProgress(progreso);
    		if(progreso==100)progressDialog.dismiss();
    		
    	}
    	
    }   // end AsyncTask
	
	
}