package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.*;		
import android.view.animation.Animation.AnimationListener;
import android.widget.TextView;

public class AnimacionListener extends Activity implements AnimationListener{
	
	int i=1;
	TextView tv;
	Animation escala;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv1= (TextView) findViewById(R.id.texto1);
        tv1.setText("Usando la interfaz AnimationListener");
        
        tv= (TextView) findViewById(R.id.texto);    
        tv.setText("CONTADOR = "+i);

        // animacion aparicion
        Animation aparicion = new AlphaAnimation(0,1);
        aparicion.setDuration(1000);
        aparicion.setFillAfter(true);
        aparicion.setRepeatMode(Animation.RESTART);
        aparicion.setRepeatCount(10);
        aparicion.setAnimationListener(this);
        
        // animacion escalado 
        // rs indica que las coordenadas son relativas
        int rs=ScaleAnimation.RELATIVE_TO_SELF;
        escala= new ScaleAnimation(1,2,1,5,rs,0.5f,rs,0.5f);
        escala.setDuration(3000);
        escala.setFillAfter(true);	

        tv.startAnimation(aparicion);
        
    }

	@Override
	public void onAnimationEnd(Animation animation) {
		tv.setText("THE END");
		tv.startAnimation(escala);
	}

	@Override
	public void onAnimationRepeat(Animation animation) {
		i++;
        tv.setText("CONTADOR = "+i);
        }

	@Override
	public void onAnimationStart(Animation animation) {		
	}
}