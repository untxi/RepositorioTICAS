package es.ugr.amaro.navegador;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class NavegadorActivity extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
	EditText editText;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        editText=(EditText) findViewById(R.id.editText1);
        Button boton1=(Button) findViewById(R.id.button1);
        boton1.setOnClickListener(this);
        Button boton2=(Button) findViewById(R.id.button2);
        boton2.setOnClickListener(this);
    }

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		int id=view.getId();
		
		if(id==R.id.button1){
		
		String uriString=editText.getText().toString();
		Uri uri=Uri.parse(uriString);
		Intent intent=new Intent(Intent.ACTION_VIEW, uri);
		startActivity(intent);

		} else if(id==R.id.button2){
			editText.setText("http://");
		}
		
	}
}