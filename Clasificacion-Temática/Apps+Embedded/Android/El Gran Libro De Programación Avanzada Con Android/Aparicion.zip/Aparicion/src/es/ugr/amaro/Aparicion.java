package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class Aparicion extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv1= (TextView) findViewById(R.id.texto1);
        tv1.setText("Animaciones: aparición y desaparición");
        
        TextView tv= (TextView) findViewById(R.id.texto);    
        tv.setText("APARECIENDO");
        
        Animation td =
        	AnimationUtils.loadAnimation(this,R.anim.aparicion);
        
        td.setRepeatMode(Animation.RESTART);
        td.setRepeatCount(20);
        tv.startAnimation(td);
        
    }
}