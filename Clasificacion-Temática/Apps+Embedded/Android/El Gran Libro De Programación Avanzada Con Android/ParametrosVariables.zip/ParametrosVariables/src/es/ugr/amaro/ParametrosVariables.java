package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ParametrosVariables extends Activity {
    /** Called when the activity is first created. */

	TextView tv;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv=(TextView) findViewById(R.id.textView);

        escribe("Metodo llamado con cero argumentos");
        escribe("Metodo llamado con un argumento",1);
        escribe("Metodo llamado con dos argumentos",1,2);
        escribe("Metodo llamado con tres argumentos",1,2,3);        
 
        int[] array= {1,2,3,4};

        escribe("Metodo llamado con un array",array);  
        
    }
    
	void escribe(String cadena, int... numeros){

		tv.append("\n"+cadena);
		for(int i: numeros) tv.append(" "+i);		
	
		int longitud=numeros.length;
		tv.append("\n El argumento se trata como un array de "+longitud);
		
	}
    
}