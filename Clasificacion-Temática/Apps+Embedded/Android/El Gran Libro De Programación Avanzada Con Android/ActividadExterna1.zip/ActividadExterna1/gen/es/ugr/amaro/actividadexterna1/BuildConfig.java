/** Automatically generated file. DO NOT MODIFY */
package es.ugr.amaro.actividadexterna1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}