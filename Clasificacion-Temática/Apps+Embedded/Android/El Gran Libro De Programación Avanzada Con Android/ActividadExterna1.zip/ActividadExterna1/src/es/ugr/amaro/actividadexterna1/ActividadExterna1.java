package es.ugr.amaro.actividadexterna1;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActividadExterna1 extends Activity implements OnClickListener{

	TextView tv;
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv=(TextView) findViewById(R.id.textView);
        Button boton=(Button) findViewById(R.id.button1);
        boton.setOnClickListener(this);
        
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		PackageManager manager=getPackageManager();
		String name="es.ugr.amaro.actividadexterna2";
		Intent intent=manager.getLaunchIntentForPackage(name);

		String action="ACTIVIDAD2";
		Intent intent2=new Intent(action);
		startActivity(intent2);
		
	}
}
