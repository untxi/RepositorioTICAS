package es.ugr.amaro.listviewclckable;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class ListViewClickable extends Activity implements OnItemClickListener{
	
	TextView tv;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        String[] grupos=getResources().getStringArray(R.array.grupos);
        tv=(TextView) findViewById(R.id.textView);
        ListView list=(ListView) findViewById(R.id.listView1);

        ArrayAdapter<String> arrayAdapter;
        arrayAdapter = new ArrayAdapter<String>(this,
        		R.layout.fila,grupos);

        list.setAdapter(arrayAdapter);
        list.setOnItemClickListener(this);        
    }

	@Override
	public void onItemClick(AdapterView<?> list, View v, int position, long id) {

		String marcado= (String) list.getItemAtPosition(position);
		tv.setText("Ha marcado el item "+position+" "+marcado);		
	}
}