package es.ugr.amaro.webviewimage;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class WebViewImageActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        WebView webView=new WebView(this);
        WebSettings webSettings=webView.getSettings();
        webSettings.setBuiltInZoomControls(true);
        // ---true para ajustar imagenes grandes a la pantalla
        webSettings.setUseWideViewPort(true);
        webView.loadUrl("file:///android_asset/gato1.jpg");
        // ---escala inicial en porcentaje
        int scaleInPercent=25;
        webView.setInitialScale(scaleInPercent);
       
        setContentView(webView);
    }
}