package es.ugr.amaro.arraylistejemplo;

import java.util.ArrayList;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ArrayListEjemploActivity extends Activity {
 
	TextView tv;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv=(TextView) findViewById(R.id.textView);
        tv.setText("  ArrayList ejemplo");
        
        ArrayList arrayList = new ArrayList();
        
        // introduce tres tipos distintos en el array
        Integer i1=new Integer(1);
        arrayList.add(i1);
        Double x1=new Double(2.34);
        arrayList.add(x1);
        Float f1=new Float(12.3);
        arrayList.add(f1);
       
        printArray(arrayList);
        
        //inserta un nuevo elemento en la primera posición
        String s1="Pepe";
        arrayList.add(0,s1);
        printArray(arrayList);
        
        // elimina el segundo elemento 
        arrayList.remove(1);
        printArray(arrayList);
        
        // sustituye un elemento
        String s2="Juan";
        arrayList.set(1, s2);
        printArray(arrayList);
        
        // convierte en array
        Object[] oArray= arrayList.toArray();
        int dim=oArray.length;
        tv.append("\nObject[] dim= "+dim);
        for(int i=0;i<dim;i++){
        	tv.append("\n "+i+": "+oArray[i]);
        }    
    }
    void printArray(ArrayList arrayList){
        int size=arrayList.size();
        tv.append("\n----Size= "+size);
        for(int i=0;i<size;i++){
        	tv.append("\n   "+i+": "+arrayList.get(i));
        }    	
    }
 }