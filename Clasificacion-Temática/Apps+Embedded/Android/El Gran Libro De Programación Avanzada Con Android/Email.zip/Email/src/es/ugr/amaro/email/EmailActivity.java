package es.ugr.amaro.email;

import java.util.StringTokenizer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class EmailActivity extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
	EditText et1,et2,et3;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button boton= (Button) findViewById(R.id.button1);
        boton.setOnClickListener(this);
        et1=(EditText) findViewById(R.id.editText1);
        et2=(EditText) findViewById(R.id.editText2);
        et3=(EditText) findViewById(R.id.editText3);
    }

	@Override
	public void onClick(View arg0) {

		// extrae direcciones en un array
		String direcciones=et1.getText().toString();
		StringTokenizer token=new StringTokenizer(direcciones);
		int n= token.countTokens();
		String[] to= new String[n];
		for(int i=0;i<n;i++) to[i]=token.nextToken();
		
		String subject=et2.getText().toString();
		String body=et3.getText().toString();
		
		Intent intent=new Intent(Intent.ACTION_SEND);
//		intent.setData(Uri.parse("mailto:"));
		intent.putExtra(Intent.EXTRA_EMAIL,to);
		intent.putExtra(Intent.EXTRA_SUBJECT, subject);
		intent.putExtra(Intent.EXTRA_TEXT, body);
		intent.setType("message/rfc822");
//		startActivity(Intent.createChooser(intent, "Email"));
		startActivity(intent);
				
	}
}