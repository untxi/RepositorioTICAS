package es.ugr.amaro.operasprovider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

public class OperasProvider extends ContentProvider{
	
//	private static final String uriString="content://es.ugr.amaro.operas/operas";
//	public static final Uri CONTENT_URI=Uri.parse(uriString);
	SQLiteDatabase db;
	
	private static class DatabaseHelper extends SQLiteOpenHelper{

		public DatabaseHelper(Context context) {
			super(context, "operas.db", null,1);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("create table if not exists "+
					"operas (id integer primary key autoincrment, " +
					"titulo text, "+
			         " compositor text, year integer);");			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub			
		}		
	}
   
	public boolean onCreate1() {
		Context context=getContext();
		DatabaseHelper dbHelper=new DatabaseHelper(context);
		db=dbHelper.getWritableDatabase();
		return (db==null)? false : true;		
	}

	@Override
	public boolean onCreate() {
		
		Context context=getContext();
		db=context.openOrCreateDatabase("operas.db",0, null);
		if(db==null) return false;
		db.execSQL("create table if not exists "+
				"operas (_id integer primary key autoincrement, titulo text, "+
				" compositor text, year integer);");
		return true;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		long fila=db.insert("operas","", values);
		Uri uri1=Uri.withAppendedPath(uri, ""+fila);
		return uri1;
	}	
	
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		Cursor cursor=db.query("operas", projection, selection, 
				selectionArgs, null, null, sortOrder);
		return cursor;
	}
	
	@Override
	public int delete(Uri uri, String whereClause, String[] whereArgs) {
		// TODO Auto-generated method stub
		return db.delete("operas", whereClause, whereArgs);
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return "MIME no definidos en amaro.provider.operas";
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

}
