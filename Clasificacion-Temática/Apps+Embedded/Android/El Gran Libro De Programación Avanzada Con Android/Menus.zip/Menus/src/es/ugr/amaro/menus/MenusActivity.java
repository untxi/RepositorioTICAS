package es.ugr.amaro.menus;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MenusActivity extends Activity {

	TextView tv;
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv=(TextView) findViewById(R.id.textView);
    }

    @Override
    public boolean  onCreateOptionsMenu(Menu menu){

    	super.onCreateOptionsMenu(menu);
    	MenuItem item1= menu.add(0,1,1,"Opción 1");
    	MenuItem item2= menu.add(0,2,2,"Opción 2");
    	MenuItem item3= menu.add(0,3,3,"Opción 3");
    	MenuItem item4= menu.add(0,4,4,"Opción 4");
    	MenuItem item5= menu.add(0,5,5,"Opción 5");
    	MenuItem item6= menu.add(0,6,6,"Opción 6");
    	MenuItem item7= menu.add(0,7,7,"Opción 7");
    	MenuItem item8= menu.add(0,8,8,"Opción 8");

    	item1.setIcon(R.drawable.ic_launcher);
    	item2.setIcon(R.drawable.ic_launcher);
        item3.setIcon(R.drawable.ic_launcher);
    	return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

    	int id= item.getItemId();
    	tv.append("\n Ha pulsado la opción "+id);    	
    	return true;

    }
        
}