package es.ugr.amaro.mapa;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MapaActivity extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
	EditText et1,et2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        et1=(EditText) findViewById(R.id.editText1);
        et2=(EditText) findViewById(R.id.editText2);
        Button boton=(Button) findViewById(R.id.button1);
        boton.setOnClickListener(this);
    }

	@Override
	public void onClick(View v) {

		String latitud=et1.getText().toString();
		String longitud=et2.getText().toString();
		String coordenadas="geo:"+latitud+","+longitud;		
		Intent intent= new Intent(android.content.Intent.ACTION_VIEW);
		intent.setData(Uri.parse(coordenadas));
		startActivity(intent);
		Toast.makeText(this, coordenadas, 1).show();
		
	}
}