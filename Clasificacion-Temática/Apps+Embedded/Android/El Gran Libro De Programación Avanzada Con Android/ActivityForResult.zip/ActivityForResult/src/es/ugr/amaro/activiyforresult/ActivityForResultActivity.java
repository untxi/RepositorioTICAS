package es.ugr.amaro.activiyforresult;

import java.util.Set;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActivityForResultActivity extends Activity implements OnClickListener{

	TextView tv;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv=(TextView) findViewById(R.id.textView);
        Button boton=(Button) findViewById(R.id.button);
        boton.setOnClickListener(this);    
    }
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent=new Intent(this,Actividad2.class);
		int inputCode=17;
		startActivityForResult(intent,inputCode);	
	}
	
	@Override
	public void onActivityResult(int inputCode, int resultCode, Intent intent2){
		
		tv.setText("onActivityResult\ninputCode= "+inputCode);
		tv.append("\nresultCode= "+resultCode);

		boolean analizarIntent=true;
		if(analizarIntent){
		if(intent2!=null){
			Bundle bundle=intent2.getExtras();
			int n=bundle.size();
			tv.append("\nbundle="+n);
			if(n>0){
				Set<String> set = intent2.getExtras().keySet();
				Object[] elementos= set.toArray();
				for(int i=0;i<n;i++)
					tv.append("\n"+elementos[i].toString());
			}
		} 
		else{
			tv.append("\nintent is null");
		}}

		if(resultCode==RESULT_OK){
			String username= intent2.getStringExtra("username");
			String password=intent2.getStringExtra("password");
			tv.append("\nBienvenido "+username+"\nSu password es "+password);
		}
	}
	
}