package es.ugr.amaro.activiyforresult;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Actividad2 extends Activity implements OnClickListener{

	EditText editText1,editText2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);
        Button boton1=(Button) findViewById(R.id.button2);
        boton1.setOnClickListener(this);
        editText1=(EditText) findViewById(R.id.editText1);
        editText2=(EditText) findViewById(R.id.editText2);
      
    }
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		String username=editText1.getText().toString();
		String password=editText2.getText().toString();
		
		Intent intent2=new Intent();
		intent2.putExtra("username",username);
		intent2.putExtra("password",password);
		setResult(RESULT_OK,intent2);
		finish();
	}
}
