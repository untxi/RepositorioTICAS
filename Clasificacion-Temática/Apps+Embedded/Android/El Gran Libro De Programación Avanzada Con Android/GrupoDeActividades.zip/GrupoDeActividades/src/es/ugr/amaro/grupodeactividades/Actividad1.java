package es.ugr.amaro.grupodeactividades;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Actividad1 extends Activity implements OnClickListener{
	
	TextView tv;
	int n=0;
	String id;
	
	@Override 
	public void onCreate(Bundle b){
		
		super.onCreate(b);
		setContentView(R.layout.ui1);
		tv=(TextView) findViewById(R.id.textView1);
		Button boton=(Button) findViewById(R.id.button1);
		boton.setOnClickListener(this);
		Button boton11=(Button) findViewById(R.id.button11);
		boton11.setOnClickListener(this);

		Intent intent=this.getIntent();
		id=intent.getStringExtra("idString");
		tv.setText("Iniciada actividad"+id);		
	}

	@Override
	public void onClick(View v) {
		int id=v.getId();
		if(id==R.id.button1){
			n++;
			tv.setText("pulsado "+n+" veces");
		}
		else if(id==R.id.button11){
			this.finish();
		}		
	}
}
