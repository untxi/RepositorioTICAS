package es.ugr.amaro;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class Dilatacion extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv1= (TextView) findViewById(R.id.texto1);
        tv1.setText("Animaciones: dilataciones y contracciones");
        
        TextView tv= (TextView) findViewById(R.id.texto);    
        tv.setText("DILATANDO");
        
        Animation td =
        	AnimationUtils.loadAnimation(this,R.anim.dilatacion);
        
        td.setRepeatMode(Animation.RESTART);
        td.setRepeatCount(20);
//        td.setFillAfter(true);

//        tv1.startAnimation(td);
        tv.startAnimation(td);
        
    }
}