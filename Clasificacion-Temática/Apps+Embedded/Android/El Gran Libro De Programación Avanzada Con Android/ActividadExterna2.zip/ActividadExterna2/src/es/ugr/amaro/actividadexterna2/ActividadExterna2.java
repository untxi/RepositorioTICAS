package es.ugr.amaro.actividadexterna2;

import android.app.Activity;
import android.os.Bundle;

public class ActividadExterna2 extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}