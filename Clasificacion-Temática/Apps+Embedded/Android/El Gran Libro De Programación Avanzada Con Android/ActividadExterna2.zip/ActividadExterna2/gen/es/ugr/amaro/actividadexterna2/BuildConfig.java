/** Automatically generated file. DO NOT MODIFY */
package es.ugr.amaro.actividadexterna2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}