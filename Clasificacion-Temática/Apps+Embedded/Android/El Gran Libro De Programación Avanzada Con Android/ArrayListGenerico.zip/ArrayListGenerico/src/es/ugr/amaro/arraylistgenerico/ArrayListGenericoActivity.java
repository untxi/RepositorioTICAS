package es.ugr.amaro.arraylistgenerico;

import java.util.ArrayList;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ArrayListGenericoActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TextView tv=(TextView) findViewById(R.id.textView);
        
        // ---ArrayList no generico
        ArrayList array1= new ArrayList();
        // introducimos un entero
        array1.add(55);
        int i= (Integer) array1.get(0);
        tv.append("\nContenido de ArrayList no generico:\n"+i);
        
        // introducimos una String
        array1.add("66");
        // la siguiente linea da error
        // i = (Integer) array1.get(1);
        
        // la siguiente linea es correcta
        String s=(String) array1.get(1);
        tv.append("\nSegundo elemento= "+s);

        // ---ArrayList generico (parametrizado)
        ArrayList<Integer> array2= new ArrayList<Integer>();
        // introducimos un entero
        array2.add(77);
        // no es necesario un cast
        int j= array2.get(0);
        tv.append("\n\nArrayList genérico:\n"+j);
        
        // la siguiente linea no compila
        //array2.add("88");
        
        // sólo sepueden añadir enteros
        array2.add(88);
        j=array2.get(1);
        tv.append("\nSegundo elemento: "+j);
        
    }
}