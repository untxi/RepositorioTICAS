package es.ugr.amaro.listviewbasico;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListViewBasicoActivity extends Activity {
    /** Called when the activity is first created. */
		
	String[]  bandasRock= {
			"Fleetwood Mac",
			"Derek and the Dominos",
			"The Bluesbreakers",
			"Queen",
			"AC-DC",
			"Black Sabbath",
			"Dire Straits",
			"Boston",
			"Train",
			"Motorhead",
			"Mott the Hoople",
			"Deep Purple",
			"ZZ Top"
	};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ListView lista=(ListView) findViewById(R.id.listView1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
        		android.R.layout.simple_list_item_1,bandasRock);

        lista.setAdapter(adapter);
                
    }
}